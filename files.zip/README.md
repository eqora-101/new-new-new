# Blue Barn Home Buyers LLC

Static website. All files sit together in ONE folder (no subfolders), so uploading is simple.

Files: index.html, style.css, script.js, logo.jpg, hero-lake.jpg, cowboy-bluebonnets.jpg, florida-waterfront.jpg

## Upload to GitHub
1. Create a new repository.
2. Click Add file > Upload files and drag in ALL files from this folder (select them all). Commit.

## Deploy on Vercel
1. In Vercel click Add New > Project and import the repository.
2. Framework Preset: Other. Leave everything else empty and click Deploy.

## Leads by email (important)
Leads go to office@bluebarnhomebuyers.com through FormSubmit.
1. After the site is live, fill out the form yourself and send a test.
2. FormSubmit emails office@bluebarnhomebuyers.com a one-time activation link. Check spam too.
3. Click the link. Leads arrive in that inbox from then on.
